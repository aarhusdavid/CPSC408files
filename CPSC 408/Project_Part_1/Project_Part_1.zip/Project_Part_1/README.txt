David Aarhus
2291228
11/02/2020
Project Part 1
CPSC 408-01
